package mu.nu.nullpo.gui.menu;

public class NullpominoMenu extends Menu{
	public NullpominoMenu(){
		super("Harry Plays Tetris","v1.1");
			}

}
